// Initialisierung der Variablen, welche global verwendet werden
let ganttChart;
let fm_format;
let time_zone;
let time_zone_end_date_offset = "Atlantic/Azores";
let date_display_format = "DD.MM.YYYY";

// Konfiguration des gantt Diagramms
const config = {
  header_height: 50,
  column_width: 30,
  step: 24,
  view_modes: ["Quarter Day", "Half Day", "Day", "Week", "Month"],
  bar_height: 20,
  bar_corner_radius: 3,
  arrow_curve: 5,
  padding: 18,
  view_mode: "Day",
  date_format: date_display_format,
  language: "de", // or 'en', 'es', 'it', 'ru', 'ptBr', 'fr', 'tr', 'zh', 'de', 'hu'
  popup_trigger: "mouseover", // default 'click'
  on_view_change: function (mode) {
    on_view_change(mode);
  },
  on_click: function (task) {
    on_click_call_fm(task);
  },
  on_date_change: function (task, start, end) {
    on_date_change_call_fm(task, start, end);
  },
  on_progress_change: function (task, progress) {
    on_progress_change_call_fm(task, progress);
  },
  custom_popup_html: function (task) {
    const startDate = task._start;
    const endDate = task._end;
    const dauer = differenzInTagen(startDate, endDate);

    const start_date = moment
      .tz(task._start, time_zone)
      .format(date_display_format);
    const end_date = moment
      .tz(task._end, time_zone_end_date_offset)
      .format(date_display_format);
      
    return `
      <div class="details-container">
        <h3>${task.name}</h3>
        <p>Start: ${start_date}</p>
        <p>Ende: ${end_date}</p>
        <p>Dauer: ${dauer} Tage</p>
        <p>Fortschritt: ${task.progress}% fertig</p>
      </div>
    `;
  },
};

/**
* Gantt-Chart wird geladen nachdem alle JS und CSS Dateien geladen wurden
*/
window.addEventListener("DOMContentLoaded", () => {
  launch_gantt();
});

let start_time = new Date();

/**
 * Daten werden von FileMaker geladen
 */
const launch_gantt = () => {
  const interval = 10; // ms

  window.setTimeout(() => {
    let end_time = new Date();
    let time_elapsed = end_time - start_time;

    if (typeof FileMaker !== "undefined") {
      FileMaker.PerformScriptWithOption("load_gantt", null, 5);
    } else if (time_elapsed >= 200) {
      const meldung = "Gantt wird nur in FileMaker angezeigt!";
      document.getElementById("gantt-container").innerHTML = meldung;
    } else {
      window.setTimeout(() => {
        launch_gantt();
      }, interval);
    }
  }, interval);
};

// Diese Funktion wird aus FileMaker beim Start/Initialisieren aufgerufen
const load_gantt = (parameter) => {
  const p = JSON.parse(parameter);

  let tasks = p.tasks;
  let task_fields = p.task_fields;

  time_zone = p.time_zone;
  fm_format = p.fm_format;

  let formatted_tasks = format_tasks(tasks, task_fields);

  ganttChart = new Gantt("#gantt", formatted_tasks, config);

  // Definition der Knöpfe für die Skallierung
  document
    .querySelector(".chart-controls #quarter-day-btn")
    .addEventListener("click", () => {
      ganttChart.change_view_mode("Quarter Day");
    });
  document
    .querySelector(".chart-controls #half-day-btn")
    .addEventListener("click", () => {
      ganttChart.change_view_mode("Half Day");
    });
  document
    .querySelector(".chart-controls #day-btn")
    .addEventListener("click", () => {
      ganttChart.change_view_mode("Day");
    });
  document
    .querySelector(".chart-controls #week-btn")
    .addEventListener("click", () => {
      ganttChart.change_view_mode("Week");
    });
  document
    .querySelector(".chart-controls #month-btn")
    .addEventListener("click", () => {
      ganttChart.change_view_mode("Month");
    });
};

// Umformatierung der FM-Tasks-Daten in ein JS-Array
const format_tasks = (tasks, fields) => {
  formatted_tasks = [];

  for (var i = 0; i < tasks.length; i++) {
    let task_element = tasks[i];
    let taskObjekt = task_element?.fieldData ? task_element.fieldData : task_element;
    let task = {};

    task.id = taskObjekt[fields.id];
    task.start = fm_to_js_date(taskObjekt[fields.start]);
    task.end = fm_to_js_date(taskObjekt[fields.end]);
    task.name = taskObjekt[fields.name];
    task.dependencies = taskObjekt[fields.dependencies];
    task.progress = taskObjekt[fields.progress];
    task.custom_class = taskObjekt[fields.custom_class];

    formatted_tasks.push(task);
  }
  return formatted_tasks;
};


/**
 * Hilfsfunktion: Umformatierung eines Datums
 * @param {*} string
 * @returns
 */
const fm_to_js_date = (string) => {
  if (string == "" || string == null) return "";
  var js_date = moment.tz(string, fm_format, time_zone);
  return js_date.format();
};

/**
 * Hauptfunktion für den FileMaker Aufruf
 * @param {*} parameter
 */
const execute_fm_script = (parameter) => {
  // Wenn option im Parameter übergeben wurde, benutze dieses, sonst nimm die 5
  const option = parameter?.option ?? 5;

  const fm_script_name = parameter.scriptName; 
  const fm_parameter = JSON.stringify(parameter);

  if (typeof FileMaker !== "undefined") {
    FileMaker.PerformScriptWithOption(
      "ext_ausfuehren_in_filemaker",
      fm_parameter,
      option,
    );
  } else {
    alert(`FileMakerSkript ${fm_script_name} konnte nicht ausgeführt werden`);
  }
};

/**
 * Funktion für die Änderung der Zeitskalla
 * @param {*} mode
 */
const on_view_change = (mode) => {
  document.getElementById("current-timescale").innerText = mode;
  // console.log("on_view_change:", mode);
};

/**
 * Funktion für den Mausklick
 * @param {*} task 
 */
const on_click_call_fm = (task) => {
  ganttChart.unselect_all();
  ganttChart.hide_popup();

  const event = "onClick";
  // console.log("event", event);

  const params = {
    task: task,
    scriptName: event,
    option: 5,
  };

  execute_fm_script(params);
};

/**
 * Funktion für die Änderung des Datums
 * @param {*} task
 * @param {*} start
 * @param {*} end
 */
const on_date_change_call_fm = (task, start, end) => {
  // console.log("on_date_change:", task, start, end);

  let startNew = moment.tz(start, time_zone).format(fm_format);
  let endNew = moment.tz(end, time_zone).format(fm_format);

  const event = "onDateChange";

  const params = {
    task: task,
    start: startNew,
    end: endNew,
    scriptName: event,
    option: 5,
  };

  execute_fm_script(params);
}

/**
 * Funktion für die Änderung des Fortschrittes
 * @param {*} task
 * @param {*} progress
 */
const on_progress_change_call_fm = (task, progress) => {
  // console.log("on_progress_change:", task, progress);
  const event = "onProgressChange";

  const params = {
    task: task,
    progress: progress,
    scriptName: event,
    option: 5,
  };

  execute_fm_script(params);
}

/**
 * Funktion wird von FileMaker aus aufgerufen
 * @param {*} parameter
 */
const refresh_tasks = (parameter) => {
  const p = JSON.parse(parameter);
  let settings = p.gantt_settings;
  let tasks = p.tasks;
  let task_fields = p.task_fields;

  let formatted_tasks = format_tasks(tasks, task_fields);

  ganttChart.refresh(formatted_tasks);
};

/**
 * Hilfsfunktion: Bestimmung der Differenz in Tagen zwischen zwei Daten
 * @param {*} start 
 * @param {*} end 
 * @returns 
 */
const differenzInTagen = (start, end) => {
  let startDate = new Date(start);
  let endDate = new Date(end);

  let milliSekunden = endDate.getTime() - startDate.getTime();
  let tage = Math.ceil(milliSekunden / (1000 * 3600 * 24));

  return tage;
};
